
public class InsufficientCommandException extends Exception {
	public InsufficientCommandException(){
		super();
		System.out.println("Insufficient command arguments!");
	}
}
