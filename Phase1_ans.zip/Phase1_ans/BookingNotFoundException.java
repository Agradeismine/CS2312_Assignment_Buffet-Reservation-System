public class BookingNotFoundException extends Exception {
    public BookingNotFoundException(){
        super();
        System.out.println("Booking not found!");
    }
}